//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_replacer.cpp
//
// Identification: src/buffer/lru_replacer.cpp
//
// Copyright (c) 2015-2019, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/lru_replacer.h"

namespace bustub {

LRUReplacer::LRUReplacer(size_t num_pages) { capacity_ = num_pages; }

LRUReplacer::~LRUReplacer() = default;

bool LRUReplacer::Victim(frame_id_t *frame_id) {
  std::lock_guard<std::mutex> guard(mutex_);
  if (frame_list_.empty()) {
    frame_id = nullptr;
    return false;
  }
  *frame_id = frame_list_.front();
  frame_list_.pop_front();
  frame_map_.erase(*frame_id);
  return true;
}

void LRUReplacer::Pin(frame_id_t frame_id) {
  std::lock_guard<std::mutex> guard(mutex_);
  std::unordered_map<frame_id_t, std::list<frame_id_t>::iterator>::iterator occurrence = frame_map_.find(frame_id);
  if (occurrence != frame_map_.end()) {
    frame_list_.erase(occurrence->second);
    frame_map_.erase(occurrence);
  }
}

void LRUReplacer::Unpin(frame_id_t frame_id) {
  std::lock_guard<std::mutex> guard(mutex_);
  if (frame_list_.size() < capacity_ && frame_map_.find(frame_id) == frame_map_.end()) {
    frame_list_.push_back(frame_id);
    frame_map_[frame_id] = (--frame_list_.end());
  }
}

size_t LRUReplacer::Size() {
  std::lock_guard<std::mutex> guard(mutex_);
  return frame_list_.size();
}

}  // namespace bustub
